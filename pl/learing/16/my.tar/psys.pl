#! /usr/bin/env perl

use strict;

# system系统调用
system 'date';
system 'ls -l $HOME';
print "\n";
system 'for i in *; do echo == $i == ; cat $i; done';

# 多参数版本,不会调用shell
system 'tar','cvf',"my.tar",".";

# exec系统调用，陷进去
exec 'date';


